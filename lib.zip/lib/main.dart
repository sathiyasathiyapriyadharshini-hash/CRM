import 'package:flutter/material.dart';
import 'Home/dashboard_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CRM App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF6B4195),
          primary: const Color(0xFF6B4195),
        ),
        useMaterial3: true,
        fontFamily: 'Poppins',
      ),
      home: const DashboardScreen(),
    );
  }
}
