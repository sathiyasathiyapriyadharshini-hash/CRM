import 'package:flutter/material.dart';

import '../Home/dashboard_screen.dart';

import 'enquiry_screen.dart';
import 'leads_screen.dart';
import '../Deals/deal_lost.dart';
import '../Deals/deal_won.dart';

class DrawerScreen extends StatelessWidget {
  const DrawerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: Colors.white,
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          const SizedBox(height: 50),

          _buildDrawerItem(
            context,
            assetPath: 'assets/icons/enquiry.png',
            title: 'Enquiry',
          ),
          _buildDivider(),

          _buildDrawerItem(
            context,
            assetPath: 'assets/icons/leads.png',
            title: 'Leads',
          ),
          _buildDivider(),

          _buildDrawerItem(
            context,
            assetPath: 'assets/icons/follows.png',
            title: 'Today Follow-ups',
          ),
          _buildDivider(),

          _buildDrawerItem(
            context,
            assetPath: 'assets/icons/missed1.png',
            title: 'Missed Follow-ups',
          ),
          _buildDivider(),

          _buildDrawerItem(
            context,
            assetPath: 'assets/icons/reshedule.png',
            title: 'Re Follow-ups',
          ),
          _buildDivider(),

          _buildDrawerItem(
            context,
            assetPath: 'assets/icons/upcoming.png',
            title: 'Up Coming Follow-ups',
          ),
          _buildDivider(),

          _buildDrawerItem(
            context,
            assetPath: 'assets/icons/meeting1.png',
            title: 'Meeting / Visit',
          ),
          _buildDivider(),

          _buildDrawerItem(
            context,
            assetPath: 'assets/icons/deals1.png',
            title: 'Deals',
          ),
          _buildDivider(),

          _buildDrawerItem(
            context,
            assetPath: 'assets/icons/deal-lost.png',
            title: 'Deal lost',
          ),
          _buildDivider(),

          _buildDrawerItem(
            context,
            assetPath: 'assets/icons/deals1.png',
            title: 'Deal Won',
          ),
        ],
      ),
    );
  }

  // 🔽 UPDATED METHOD (IconData → String assetPath)
  Widget _buildDrawerItem(
    BuildContext context, {
    required String assetPath,
    required String title,
  }) {
    return ListTile(
      leading: Image.asset(
        assetPath,
        width: 24,
        height: 24,
        color: const Color(0xFF6B4195),
      ),
      title: Text(
        title,
        style: const TextStyle(
          color: Colors.black,
          fontSize: 16,
          fontWeight: FontWeight.w400,
        ),
      ),
      onTap: () {
        if (title == 'Enquiry') {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const EnquiryScreen()),
          );
        } else if (title == 'Today Follow-ups') {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => const DashboardScreen(
                initialIndex: 1,
                followUpInitialIndex: 0,
              ),
            ),
          );
        } else if (title == 'Re Follow-ups') {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => const DashboardScreen(
                initialIndex: 1,
                followUpInitialIndex: 1,
              ),
            ),
          );
        } else if (title == 'Up Coming Follow-ups') {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => const DashboardScreen(
                initialIndex: 1,
                followUpInitialIndex: 2,
              ),
            ),
          );
        } else if (title == 'Missed Follow-ups') {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => const DashboardScreen(
                initialIndex: 1,
                followUpInitialIndex: 3,
              ),
            ),
          );
        } else if (title == 'Leads') {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const LeadsScreen()),
          );
        } else if (title == 'Deals') {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => const DashboardScreen(initialIndex: 2),
            ),
          );
        } else if (title == 'Deal Won') {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => const DealWonScreen()),
          );
        } else if (title == 'Deal lost') {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => const DealLostScreen()),
          );
        } else if (title == 'Meeting / Visit') {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => const DashboardScreen(initialIndex: 3),
            ),
          );
        }
      },
      contentPadding: const EdgeInsets.symmetric(horizontal: 24),
      visualDensity: const VisualDensity(horizontal: 0, vertical: -2),
    );
  }

  Widget _buildDivider() {
    return const Divider(
      color: Color(0xFFE0E0E0),
      height: 1,
      thickness: 1,
      indent: 24,
      endIndent: 24,
    );
  }
}
