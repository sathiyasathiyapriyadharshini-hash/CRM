import 'package:flutter/material.dart';

class LeadsScreen extends StatelessWidget {
  const LeadsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text(
          'Leads',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w500),
        ),
        backgroundColor: const Color(0xFF6B4195),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search, color: Colors.white),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(
              Icons.calendar_month_outlined,
              color: Colors.white,
            ),
            onPressed: () {},
          ),
        ],
      ),
      body: Column(
        children: [
          // Filter Section
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                OutlinedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.filter_list, color: Colors.black),
                  label: const Text(
                    'Sort by',
                    style: TextStyle(color: Colors.black),
                  ),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Color(0xFF6B4195)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(4),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Lead Cards List
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                _buildLeadCard(
                  name: 'Harish',
                  priority: 'High',
                  priorityColor: Colors.red,
                  company: 'HM Tech Solutions',
                  email: 'hmtechsolutions@gmail.com',
                  detail: '+91 98765 43210',
                  detailIcon: Icons.phone_android,
                  status: 'Qualified',
                  statusColor: const Color(0xFF76E888), // Light Green
                  statusTextColor: Colors.green[900]!,
                ),
                _buildLeadCard(
                  name: 'Harish',
                  priority: 'Medium',
                  priorityColor: Colors.blue,
                  company: 'HM Tech Solutions',
                  email: 'hmtechsolutions@gmail.com',
                  detail: 'Advertisement',
                  detailIcon:
                      Icons.center_focus_weak, // Using a generic icon for Ad
                  status: 'Contacted',
                  statusColor: const Color(0xFF448AFF), // Blue
                  statusTextColor: Colors.white,
                ),
                _buildLeadCard(
                  name: 'Harish',
                  priority: 'Low',
                  priorityColor: Colors.grey,
                  company: 'HM Tech Solutions',
                  email: 'hmtechsolutions@gmail.com',
                  detail: 'Referral', // Correction from "Refferal"
                  detailIcon: Icons.people_outline,
                  status: 'Qualified',
                  statusColor: const Color(0xFF76E888),
                  statusTextColor: Colors.green[900]!,
                ),
                _buildLeadCard(
                  name: 'Harish',
                  priority: 'High',
                  priorityColor: Colors.red,
                  company: 'HM Tech Solutions',
                  email: 'hmtechsolutions@gmail.com',
                  detail: 'Social Media',
                  detailIcon: Icons.public,
                  status: 'Contacted',
                  statusColor: const Color(0xFF448AFF),
                  statusTextColor: Colors.white,
                ),
                _buildLeadCard(
                  name: 'Harish',
                  priority: 'High',
                  priorityColor: Colors.red,
                  company: 'HM Tech Solutions',
                  email: 'hmtechsolutions@gmail.com',
                  detail: 'website',
                  detailIcon: Icons.language,
                  status: 'Qualified',
                  statusColor: const Color(0xFF76E888),
                  statusTextColor: Colors.green[900]!,
                ),
                _buildLeadCard(
                  name: 'Harish',
                  priority: 'High',
                  priorityColor: Colors.red,
                  company: 'HM Tech Solutions',
                  email: 'hmtechsolutions@gmail.com',
                  detail: 'website',
                  detailIcon: Icons.language,
                  status: 'Qualified',
                  statusColor: const Color(0xFF76E888),
                  statusTextColor: Colors.green[900]!,
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
        backgroundColor: const Color(0xFF6B4195),
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }

  Widget _buildLeadCard({
    required String name,
    required String priority,
    required Color priorityColor,
    required String company,
    required String email,
    required String detail,
    required IconData detailIcon,
    required String status,
    required Color statusColor,
    required Color statusTextColor,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              RichText(
                text: TextSpan(
                  text: name,
                  style: const TextStyle(
                    color: Colors.black,
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                  children: [
                    const TextSpan(
                      text: ' | Priority : ',
                      style: TextStyle(
                        color: Colors.black54,
                        fontSize: 14,
                        fontWeight: FontWeight.normal,
                      ),
                    ),
                    TextSpan(
                      text: priority,
                      style: TextStyle(
                        color: priorityColor,
                        fontSize: 14,
                        fontWeight: FontWeight.normal,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 4,
                ),
                decoration: BoxDecoration(
                  color: statusColor,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  status,
                  style: TextStyle(
                    color: statusTextColor,
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          _buildInfoRow(
            Icons.apartment,
            company,
          ), // Using apartment as generic building icon
          const SizedBox(height: 4),
          _buildInfoRow(Icons.mail_outline, email),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildInfoRow(detailIcon, detail, isDetail: true),
              GestureDetector(
                onTap: () {
                  // View full detail
                },
                child: const Text(
                  'View Full Detail >>',
                  style: TextStyle(
                    color: Color(0xFF5E6C84), // Greyish blue link color
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    decoration: TextDecoration.underline,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String text, {bool isDetail = false}) {
    return Row(
      children: [
        Icon(
          icon,
          size: 18,
          color: const Color(0xFF6B4195),
        ), // Purple icons as per consistency or Grey? Figma has blue/grey icons.
        // Figma shows blueish icons. Let's use a standard blue-grey or the theme purple.
        // The image shows icons are blue/purple (indigo). I'll use a specific color.
        const SizedBox(width: 8),
        Text(
          text,
          style: TextStyle(
            fontSize: 14,
            color: Colors.grey[700],
            fontWeight: FontWeight.normal,
          ),
        ),
      ],
    );
  }
}
