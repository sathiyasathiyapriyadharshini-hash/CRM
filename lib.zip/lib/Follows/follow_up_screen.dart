import 'package:flutter/material.dart';

class FollowUpScreen extends StatefulWidget {
  final int initialIndex;
  final VoidCallback? onBack;

  const FollowUpScreen({super.key, this.initialIndex = 0, this.onBack});

  @override
  State<FollowUpScreen> createState() => _FollowUpScreenState();
}

class _FollowUpScreenState extends State<FollowUpScreen> {
  late int _selectedIndex;
  bool _isQuickMenuExpanded = false;

  @override
  void initState() {
    super.initState();
    _selectedIndex = widget.initialIndex;
  }

  // Helper to get properties based on selected index
  String get _title {
    switch (_selectedIndex) {
      case 0:
        return 'Today Follow-up';
      case 1:
        return 'Re Follow-ups'; // Matches screenshot 2
      case 2:
        return 'Up Coming Follow-ups'; // Matches screenshot 3
      case 3:
        return 'Missed Follow-ups'; // Matches screenshot 4
      default:
        return 'Follow-up';
    }
  }

  String get _summaryTitle {
    switch (_selectedIndex) {
      case 0:
        return 'Today Follow-up';
      case 1:
        return 'Re Follow-up';
      case 2:
        return 'Upcoming';
      case 3:
        return 'Missed Follow-up';
      default:
        return 'Follow-up';
    }
  }

  String get _summaryCount {
    switch (_selectedIndex) {
      case 0:
        return '10';
      case 1:
        return '8';
      case 2:
        return '8';
      case 3:
        return '8';
      default:
        return '0';
    }
  }

  String get _assetIcon {
    switch (_selectedIndex) {
      case 0:
        return 'assets/icons/today.png';
      case 1:
        return 'assets/icons/reschedule.png'; // Assuming asset exists or fallback
      case 2:
        return 'assets/icons/upcoming.png'; // Assuming asset exists or fallback
      case 3:
        return 'assets/icons/missed.png';
      default:
        return 'assets/icons/today.png';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: const Color(0xFF6B4195),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            if (widget.onBack != null) {
              widget.onBack!();
            } else if (Navigator.canPop(context)) {
              Navigator.pop(context);
            }
          },
        ),
        title: Text(
          _title,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.w500,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(
              Icons.calendar_month_outlined,
              color: Colors.white,
            ),
            onPressed: () {},
          ),
        ],
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Top Action Buttons Row
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade200),
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildCircleAction('assets/icons/follows.png', 0),
                        _buildCircleAction('assets/icons/reshedule.png', 1),
                        _buildCircleAction('assets/icons/upcoming.png', 2),
                        _buildCircleAction(
                          'assets/icons/missed1.png', // Replaced call_missed to look closer to Figma loop
                          3,
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildFilterChip('Today', 0),
                        _buildFilterChip('Re\nSchedule', 1),
                        _buildFilterChip('up\nComing', 2),
                        _buildFilterChip('Missed', 3),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              // Summary Card
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade200),
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Dynamic Icon
                        Image.asset(
                          _assetIcon,
                          width: 40,
                          height: 40,
                          errorBuilder: (c, e, s) {
                            if (_selectedIndex == 0) {
                              return Image.asset(
                                'assets/icons/today_followup.png', // Fallback name check
                                width: 40,
                                height: 40,
                                errorBuilder: (c, e, s) => const Icon(
                                  Icons.calendar_today,
                                  size: 40,
                                  color: Colors.redAccent,
                                ),
                              );
                            }
                            if (_selectedIndex == 1) {
                              return const Icon(
                                Icons.group_add_rounded,
                                size: 40,
                                color: Colors.orange,
                              );
                            }
                            if (_selectedIndex == 2) {
                              return const Icon(
                                Icons.calendar_month_outlined,
                                size: 40,
                                color: Colors.cyan,
                              );
                            }
                            return const Icon(
                              Icons.ads_click_rounded,
                              size: 40,
                              color: Colors.redAccent,
                            );
                          },
                        ),
                        const SizedBox(width: 12),
                        Text(
                          _summaryTitle,
                          style: const TextStyle(
                            fontSize: 16,
                            color: Color(0xFF6B4195),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFF6B4195),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        _summaryCount,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              // List Items
              // List Items
              if (_selectedIndex == 0) ...[
                // Today Follow-up List
                const Text(
                  'Today Follow-up List',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    color: Colors.black,
                  ),
                ),
                const SizedBox(height: 12),
                _buildFollowUpCard(
                  name: 'Arun Kumar',
                  leadNo: 'L001',
                  time: '10:00 AM',
                  tag: 'new',
                  tagColor: const Color(0xFF4FDB09),
                ),
                _buildFollowUpCard(
                  name: 'Lakshimi',
                  leadNo: 'L004',
                  time: '10:40 AM',
                  tag: 'new',
                  tagColor: const Color(0xFFECA883),
                ),
                _buildFollowUpCard(
                  name: 'Arun Kumar',
                  leadNo: 'L001',
                  time: '10:00 AM',
                  tag: 'new',
                  tagColor: const Color(0xFF4FDB09),
                ),
              ] else if (_selectedIndex == 1) ...[
                // Re Follow-up Data
                _buildFollowUpCard(
                  name: 'Lakshimi',
                  leadNo: 'L004',
                  time: '10:40 AM',
                  reason: 'Customer not available',
                  hasLeftBorder: true,
                  borderColor: const Color(0xFF4FDB09),
                ),
                _buildFollowUpCard(
                  name: 'Arun Kumar',
                  leadNo: 'L001',
                  time: '10:00 AM',
                  reason: 'Customer Cancelled',
                  hasLeftBorder: true,
                  borderColor: const Color(0xFF4FDB09),
                ),
                _buildFollowUpCard(
                  name: 'Dhana',
                  leadNo: 'L006',
                  time: '11:00 AM',
                  reason: 'Price High',
                  hasLeftBorder: true,
                  borderColor: const Color(0xFF4FDB09),
                ),
                _buildFollowUpCard(
                  name: 'meena',
                  leadNo: 'L011',
                  time: '09:00 AM',
                  reason: 'Price High',
                  hasLeftBorder: true,
                  borderColor: const Color(0xFF4FDB09),
                ),
              ] else if (_selectedIndex == 2) ...[
                // Upcoming Data
                _buildFollowUpCard(
                  name: 'Lakshimi',
                  leadNo: 'L004',
                  time: '10:40 AM',
                  hasLeftBorder: true,
                  borderColor: const Color(0xFF4FDB09),
                ),
                _buildFollowUpCard(
                  name: 'Arun Kumar',
                  leadNo: 'L001',
                  time: '10:00 AM',
                  hasLeftBorder: true,
                  borderColor: const Color(0xFF4FDB09),
                ),
                _buildFollowUpCard(
                  name: 'Dhana',
                  leadNo: 'L006',
                  time: '11:00 AM',
                  hasLeftBorder: true,
                  borderColor: const Color(0xFF4FDB09),
                ),
                _buildFollowUpCard(
                  name: 'meena',
                  leadNo: 'L011',
                  time: '09:00 AM',
                  hasLeftBorder: true,
                  borderColor: const Color(0xFF4FDB09),
                ),
              ] else if (_selectedIndex == 3) ...[
                // Missed Data
                _buildFollowUpCard(
                  name: 'Lakshimi',
                  leadNo: 'L004',
                  time: '10:40 AM',
                  reason: 'Customer not available',
                  hasLeftBorder: true,
                  borderColor: Color(0xffDB0909),
                  showRescheduleButton: true,
                ),
                _buildFollowUpCard(
                  name: 'Arun Kumar',
                  leadNo: 'L001',
                  time: '10:00 AM',
                  reason: 'Customer Cancelled',
                  hasLeftBorder: true,
                  borderColor: Color(0xffDB0909),
                  showRescheduleButton: true,
                ),
                _buildFollowUpCard(
                  name: 'Dhana',
                  leadNo: 'L006',
                  time: '11:00 AM',
                  reason: 'Price High',
                  hasLeftBorder: true,
                  borderColor: Color(0xffDB0909),
                  showRescheduleButton: true,
                ),
                _buildFollowUpCard(
                  name: 'Dhana',
                  leadNo: 'L006',
                  time: '10:00 AM',
                  reason: 'Price High',
                  hasLeftBorder: true,
                  borderColor: Color(0xffDB0909),
                  showRescheduleButton: true,
                ),
              ],

              const SizedBox(height: 80),
            ],
          ),
        ),
      ),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (_isQuickMenuExpanded) ...[
            _buildQuickActionItem(Icons.chat_bubble_outline, () {}),
            const SizedBox(height: 12),
            _buildQuickActionItem(Icons.email_outlined, () {}),
            const SizedBox(height: 12),
            _buildQuickActionItem(Icons.phone_outlined, () {}),
            const SizedBox(height: 12),
            _buildQuickActionItem(Icons.message_outlined, () {}),
            const SizedBox(height: 12),
          ],
          GestureDetector(
            onTap: () {
              setState(() {
                _isQuickMenuExpanded = !_isQuickMenuExpanded;
              });
            },
            child: Container(
              width: 70,
              height: 70,
              decoration: const BoxDecoration(shape: BoxShape.circle),
              clipBehavior: Clip.antiAlias,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Image.asset(
                    'assets/icons/ellipse.png',
                    width: 70,
                    height: 70,
                    fit: BoxFit.cover,
                    errorBuilder: (c, e, s) => Container(
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(
                          colors: [Color(0xFF8E99F3), Color(0xFFC78BF9)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                      ),
                    ),
                  ),
                  const Text(
                    'Quick',
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCircleAction(String assetPath, int index) {
    bool isSelected = _selectedIndex == index;

    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedIndex = index;
        });
      },
      child: Container(
        width: 50,
        height: 50,
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF6B4195) : Colors.white,
          shape: BoxShape.circle,
          border: isSelected ? null : Border.all(color: Colors.grey.shade200),
        ),
        child: Center(
          child: Image.asset(
            assetPath,
            width: 24,
            height: 24,
            color: isSelected ? Colors.white : const Color(0xFF6B4195),
          ),
        ),
      ),
    );
  }

  Widget _buildFilterChip(String label, int index) {
    bool isSelected = _selectedIndex == index;
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedIndex = index;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF6B4195) : const Color(0xFFF3F0F5),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          label,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: isSelected ? Colors.white : const Color(0xFF6B4195),
            fontSize: 12,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }

  Widget _buildFollowUpCard({
    required String name,
    required String leadNo,
    required String time,
    String? tag,
    Color? tagColor,
    String? reason,
    bool hasLeftBorder = false,
    Color borderColor = const Color(0xFF76E888),
    bool showRescheduleButton = false,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          if (hasLeftBorder)
            Container(
              width: 4,
              height: reason != null
                  ? 100
                  : 80, // Dynamic height based on fields
              decoration: BoxDecoration(
                color: borderColor,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(12),
                  bottomLeft: Radius.circular(12),
                ),
              ),
            ),
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFFF7F7F7),
                borderRadius: hasLeftBorder
                    ? const BorderRadius.only(
                        topRight: Radius.circular(12),
                        bottomRight: Radius.circular(12),
                      )
                    : BorderRadius.circular(12),
                border: Border.all(color: Colors.grey.shade200),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildInfoRow(Icons.person_outline, 'Name', name),
                        const SizedBox(height: 4),
                        _buildInfoRow(Icons.track_changes, 'Lead No', leadNo),
                        const SizedBox(height: 4),
                        _buildInfoRow(Icons.calendar_month, 'Time', time),
                        if (reason != null) ...[
                          const SizedBox(height: 4),
                          _buildInfoRow(
                            Icons.center_focus_weak_sharp,
                            'Reason',
                            reason,
                            valueColor: borderColor,
                          ),
                        ],
                        if (_selectedIndex == 0) ...[
                          const SizedBox(height: 4),
                          _buildInfoRow(
                            Icons.track_changes_outlined,
                            'Purpose',
                            '',
                          ),
                        ],
                      ],
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      if (tag != null && tagColor != null)
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 4,
                          ),
                          decoration: BoxDecoration(
                            color: tagColor,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            tag,
                            style: const TextStyle(
                              color: Colors.black,
                              fontSize: 12,
                            ),
                          ),
                        ),
                      if (showRescheduleButton)
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFF7B7B),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: const Text(
                            'Reschedule',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      const SizedBox(height: 8),
                      const Icon(Icons.more_vert, color: Colors.purple),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(
    IconData icon,
    String label,
    String value, {
    Color? valueColor,
  }) {
    return Row(
      children: [
        Icon(icon, size: 16, color: Colors.black87),
        const SizedBox(width: 8),
        Text(
          '$label  : ',
          style: const TextStyle(fontSize: 14, color: Colors.black87),
        ),
        Expanded(
          child: Text(
            value,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 14,
              color: valueColor ?? Colors.black,
              fontWeight: FontWeight.normal,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildQuickActionItem(IconData icon, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 45,
        height: 45,
        decoration: const BoxDecoration(
          color: Color(0xFF6B4195),
          shape: BoxShape.circle,
        ),
        child: Icon(icon, color: Colors.white, size: 24),
      ),
    );
  }
}
