import 'package:flutter/material.dart';

class CustomBottomNav extends StatelessWidget {
  final int currentIndex;
  final Function(int) onTap;

  const CustomBottomNav({
    super.key,
    required this.currentIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF6B4195),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildNavItem(icon: 'assets/icons/home.png', label: 'Home', index: 0),
              _buildNavItem(icon: 'assets/icons/follows.png', label: 'Follows', index: 1),
              _buildNavItem(icon: 'assets/icons/deals.png', label: 'Deals', index: 2),
              _buildNavItem(icon: 'assets/icons/meetings.png', label: 'Meeting', index: 3),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem({
  required String icon, // ✅ changed
  required String label,
  required int index,
}) {
  final isActive = currentIndex == index;

  return GestureDetector(
    onTap: () => onTap(index),
    behavior: HitTestBehavior.opaque,
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Image.asset(
            icon,
            color: isActive ? Colors.white : Colors.white.withOpacity(0.5),
            width: 24,
            height: 24,
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(
              color: isActive
                  ? Colors.white
                  : Colors.white.withOpacity(0.5),
              fontSize: 12,
              fontWeight: FontWeight.w400,
            ),
          ),
        ],
      ),
    ),
  );
}

}
