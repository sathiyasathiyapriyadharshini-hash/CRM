import 'package:flutter/material.dart';

class AddMeetingScreen extends StatefulWidget {
  const AddMeetingScreen({super.key});

  @override
  State<AddMeetingScreen> createState() => _AddMeetingScreenState();
}

class _AddMeetingScreenState extends State<AddMeetingScreen> {
  final Color primaryPurple = const Color(0xFF6B4195);
  String? _selectedMeetingType;
  bool _isMeetingTypeExpanded = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: primaryPurple,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Add Meeting',
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            // Custom Expandable Selection
            GestureDetector(
              onTap: () {
                setState(() {
                  _isMeetingTypeExpanded = !_isMeetingTypeExpanded;
                });
              },
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 12,
                ),
                decoration: BoxDecoration(
                  color: primaryPurple,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      _selectedMeetingType ?? 'Select Meeting Type',
                      style: const TextStyle(color: Colors.white, fontSize: 16),
                    ),
                    const Icon(Icons.arrow_drop_down, color: Colors.white),
                  ],
                ),
              ),
            ),
            if (_isMeetingTypeExpanded) ...[
              const SizedBox(height: 8),
              _buildMeetingOption('Direct'),
              const SizedBox(height: 8),
              _buildMeetingOption('Phone Call'),
              const SizedBox(height: 8),
              _buildMeetingOption('Video Call'),
            ],
            const SizedBox(height: 24),

            // Form Fields
            _buildTextField(label: 'Customer Name'),
            const SizedBox(height: 20),
            _buildTextField(label: 'Lead No'),
            const SizedBox(height: 20),
            _buildTextField(label: 'Phone No'),
            const SizedBox(height: 20),

            Row(
              children: [
                Expanded(child: _buildTextField(label: 'Date')),
                const SizedBox(width: 16),
                Expanded(child: _buildTextField(label: 'Time')),
              ],
            ),
            const SizedBox(height: 20),
            _buildTextField(label: 'Assigned Staff'),
            const SizedBox(height: 20),
            _buildTextField(label: 'Remarks', maxLines: 5),
          ],
        ),
      ),
    );
  }

  Widget _buildMeetingOption(String title) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedMeetingType = title;
          _isMeetingTypeExpanded = false;
        });
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: const Color(0xFFF7F7F7),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: Colors.grey.shade300),
        ),
        child: Text(
          title,
          style: const TextStyle(color: Colors.black, fontSize: 16),
        ),
      ),
    );
  }

  Widget _buildTextField({required String label, int maxLines = 1}) {
    return TextField(
      maxLines: maxLines,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(
          color: primaryPurple.withOpacity(0.8),
          fontSize: 14,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey.shade300),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: primaryPurple),
        ),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 12,
        ),
      ),
    );
  }
}
