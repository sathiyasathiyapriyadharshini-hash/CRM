import 'package:crm/Deals/deals_screen.dart';
import 'package:crm/Meeting/meeting_screen.dart';
import 'package:crm/Follows/follow_up_screen.dart';
import 'package:flutter/material.dart';
import '../BottomBar/custom_bottom_nav.dart';
import '../Drawer/drawer_screen.dart';

class DashboardScreen extends StatefulWidget {
  final int initialIndex;
  final int followUpInitialIndex;

  const DashboardScreen({
    super.key,
    this.initialIndex = 0,
    this.followUpInitialIndex = 0,
  });

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
  }

  // Method to get current screen
  Widget _getCurrentScreen() {
    switch (_currentIndex) {
      case 0:
        return _DashboardContent();
      case 1:
        return FollowUpScreen(
          initialIndex: widget.followUpInitialIndex,
          onBack: () => setState(() => _currentIndex = 0),
        );
      case 2:
        return DealsScreen(onBack: () => setState(() => _currentIndex = 0));
      case 3:
        return MeetingVisitScreen(
          onBack: () => setState(() => _currentIndex = 0),
        );
      default:
        return _DashboardContent();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      drawer: const DrawerScreen(),
      // The individual screens now provide their own AppBars as per previous design,
      // but to keep bottom bar visible, we host them as body.
      // If the screens have their own Scaffold + AppBar, we might get double app bars.
      // However, the user wants the bottom bar to stay.
      // I will refactor Dashboard to be the Shell without its own AppBar when sub-screens are shown,
      // OR let the sub-screens define the body and Dashboard define the AppBar.
      // Looking at previous edits, the sub-screens HAVE their own AppBars.
      // So I'll hide Dashboard AppBar for sub-screens.
      appBar: _currentIndex == 0
          ? AppBar(
              backgroundColor: const Color(0xFF6B4195),
              elevation: 0,
              leading: Builder(
                builder: (context) {
                  return IconButton(
                    icon: const Icon(Icons.menu, color: Colors.white),
                    onPressed: () {
                      Scaffold.of(context).openDrawer();
                    },
                  );
                },
              ),
              title: Text(
                _getAppBarTitle(),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w500,
                ),
              ),
              actions: _buildAppBarActions(),
            )
          : null,
      body: _getCurrentScreen(),
      bottomNavigationBar: CustomBottomNav(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
      ),
    );
  }

  String _getAppBarTitle() {
    switch (_currentIndex) {
      case 0:
        return 'Home';
      case 1:
        return 'Follows';
      case 2:
        return 'Deals';
      case 3:
        return 'Meeting';
      default:
        return 'Home';
    }
  }

  List<Widget> _buildAppBarActions() {
    return [
      IconButton(
        icon: const Icon(Icons.search, color: Colors.white),
        onPressed: () {
          // TODO: Implement search
        },
      ),
      IconButton(
        icon: const Icon(Icons.notifications_outlined, color: Colors.white),
        onPressed: () {
          // TODO: Open notifications
        },
      ),
      IconButton(
        icon: const Icon(Icons.more_vert, color: Colors.white),
        onPressed: () {
          // TODO: Show more options
        },
      ),
    ];
  }

  static Widget _buildPlaceholderScreen(String title) {
    return Center(
      child: Text(
        '$title Coming Soon',
        style: const TextStyle(fontSize: 20, color: Colors.grey),
      ),
    );
  }
}

// Dashboard Content Widget (Home Screen)
class _DashboardContent extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Dashboard Header
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Dashboard',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    color: Color(0xFF6B4195),
                  ),
                ),
                const SizedBox(height: 5),
                const Text(
                  'Customer Management Hub',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: Color(0xFF0B0B0B),
                  ),
                ),
              ],
            ),
          ),

          // Today Follow-up Count Section
          _buildSectionCard(
            title: 'Today Follow-up Count',
            gradient: const LinearGradient(
              colors: [Color(0xFFFFFFFF), Color(0xFFF7CCFF)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            children: [
              _buildCountCard(
                assetPath: 'assets/icons/today.png',
                label: 'Today',
                count: '20',
              ),
              _buildCountCard(
                assetPath: 'assets/icons/missed.png',
                label: 'Missed',
                count: '5',
              ),
              _buildCountCard(
                assetPath: 'assets/icons/new.png',
                label: 'New',
                count: '6',
              ),
            ],
          ),

          const SizedBox(height: 16),

          // Deals Count Section
          _buildSectionCard(
            title: 'Deals Count',
            backgroundColor: const Color(0xFFB9FDD7),
            children: [
              _buildCountCard(
                assetPath: 'assets/icons/won.png',
                label: 'Won',
                count: '10',
              ),
              _buildCountCard(
                assetPath: 'assets/icons/pending.png',
                label: 'Pending',
                count: '6',
              ),
              _buildCountCard(
                assetPath: 'assets/icons/lost.png',
                label: 'Lost',
                count: '6',
              ),
            ],
          ),

          const SizedBox(height: 16),

          // Quick Actions Section
          _buildSectionCard(
            title: 'Quick Actions',
            backgroundColor: const Color(0xFFD4E9FF),
            children: [
              _buildActionButton(
                icon: Icons.add,
                label: 'Add\nEnquiry',
                onTap: () {
                  // TODO: Add enquiry
                },
              ),
              _buildActionButton(
                icon: Icons.add,
                label: 'Add\nFollow-up',
                onTap: () {
                  // TODO: Add follow-up
                },
              ),
              _buildActionButton(
                icon: Icons.add,
                label: 'Add\nMeeting',
                onTap: () {
                  // TODO: Add meeting
                },
              ),
            ],
          ),

          const SizedBox(height: 16),

          // Lead Pipeline Status Section
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(color: const Color(0xFFDEDEDE)),
                borderRadius: BorderRadius.circular(16),
              ),
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'October Month Lead Pipeline Status',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 16),
                  _buildProgressItem(
                    label: 'New Leads',
                    percentage: 40,
                    color: const Color(0xFF4A90E2),
                  ),
                  const SizedBox(height: 12),
                  _buildProgressItem(
                    label: 'In Progress',
                    percentage: 25,
                    color: const Color(0xFFF5A623),
                  ),
                  const SizedBox(height: 12),
                  _buildProgressItem(
                    label: 'Won Deals',
                    percentage: 20,
                    color: const Color.fromARGB(255, 87, 151, 18),
                  ),
                  const SizedBox(height: 12),
                  _buildProgressItem(
                    label: 'Lost Deals',
                    percentage: 15,
                    color: const Color.fromARGB(255, 193, 23, 43),
                  ),
                ],
              ),
            ),
          ),

          // Space between pipeline card and bottom bar
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _buildSectionCard({
    required String title,
    Color? backgroundColor,
    Gradient? gradient,
    required List<Widget> children,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Container(
        decoration: BoxDecoration(
          color: gradient == null ? backgroundColor : null,
          gradient: gradient,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: const Color(0x40000000),
              blurRadius: 8,
              offset: const Offset(0, 4),
              spreadRadius: 0,
            ),
          ],
        ),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: children,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCountCard({
    required String assetPath,
    required String label,
    required String count,
  }) {
    return Container(
      width: 95,
      height: 100,
      padding: const EdgeInsets.all(8),
      decoration: const BoxDecoration(color: Colors.white),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(assetPath, width: 32, height: 32),
          const SizedBox(height: 8),
          Text(
            '$label $count',
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w400,
              color: Colors.black87,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 95,
        height: 100,
        padding: const EdgeInsets.all(8),
        decoration: const BoxDecoration(color: Colors.white),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: const BoxDecoration(
                color: Color(0xFF2196F3),
                shape: BoxShape.rectangle,
              ),
              child: Icon(icon, color: Colors.white, size: 24),
            ),
            const SizedBox(height: 8),
            Text(
              label,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w400,
                color: Colors.black87,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProgressItem({
    required String label,
    required int percentage,
    required Color color,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Container(
                  width: 12,
                  height: 12,
                  decoration: BoxDecoration(
                    color: color,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  label,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
            Text(
              '$percentage%',
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w400,
                color: Colors.black87,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: percentage / 100,
              backgroundColor: Colors.grey[200],
              valueColor: AlwaysStoppedAnimation<Color>(color),
              minHeight: 8,
            ),
          ),
        ),
      ],
    );
  }
}
